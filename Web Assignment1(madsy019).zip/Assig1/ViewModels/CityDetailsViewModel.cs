﻿namespace Assig1.ViewModels
{
    public class CityDetailsViewModel
    {
    }
}
